 /**
 * This program inputs data
 * @author Lindiwe Mutungamiri
 * @param 
 * 
 * @return no return value for the method
 * 
 */
import java.util.Calendar;
import java.util.Scanner;
import java.util.InputMismatchException;

import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;


public class InputDataScanner {

	/**
	 * Constructor
	 */
	public InputDataScanner() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * 
	 * @param args
	 * @throws InputMismatchException
	 */

	public static void main(String args[]) 
	{
		//A new scanner class
		//You can pass an object of "FileInputStream("filename.txt")" 
		//to read from file
		//REMEMBER: "System.in" reads data from devices such as a keyboard
		long start = Calendar.getInstance().getTime().getTime(); // time before program is executed
		try{
		System.out.println("Creating a new item");
		
		/**
		 * entering the item, price and quantity 
		 * using the scanner
		 */
		Scanner itm = new Scanner(System.in);
		System.out.println("Enter the product name");
		String item= itm.nextLine();

		Scanner qty = new Scanner(System.in);
		System.out.println("Enter the quantity");
		int quantity= qty.nextInt();

		Scanner pr = new Scanner(System.in);
		System.out.println("Enter the price");
		double price= itm.nextDouble();

		Product newItem= new Product(item, quantity, price );
		newItem.printItem();

		   
		FileWriter fileWriter = new FileWriter("essentials_stock.txt", true); //Set true for append mode
		FileWriter fileWriter1 = new FileWriter("backup_essentials_stock.txt", true);
		PrintWriter printWriter = new PrintWriter(fileWriter);
		PrintWriter printWriter1 = new PrintWriter(fileWriter1);

		printWriter.print(newItem.printItem() + "\n");  //New line
		printWriter1.print(newItem.printItem() + "\n"); 
		printWriter.close();
		printWriter1.close();

		BufferedReader br = new BufferedReader(new FileReader("essentials_stock.txt"));
        String line;
        while ((line = br.readLine()) != null) {
          System.out.println(line);
        }
	}catch (IOException e) {
		e.printStackTrace();
	}catch (InputMismatchException e){
		System.out.println("\nPlease enter the right input");

	}
	long end = Calendar.getInstance().getTime().getTime(); // time after program completes execution
    long duration = (end - start)/1000; // calculation of runtime in seconds
	System.out.println("\nRuntime: " + duration + " seconds");
}
}