 /**
 * This class has setters and getters for the product
 * @author Lindiwe Mutungamiri
 * 
 * @return no return value for the method
 * 
 */
import java.util.Scanner;

public class Product{
    private String item;
    private int quantity;
    private double price;

    public Product(String item, int quantity, double price){ //initializing the constructor
        this.item = item;
        this.quantity = quantity;
        this.price = price;

    }
/**
 * creating setter methods to set the name
 * quantity and price of the product
 * 
 * @param name
 */
    public void setItem(String name){
        this.item = name;
    }
    public void setQuantity(int qty){
        this.quantity = qty;
    }
    public void setPrice(int pr){
        this.price = pr;
    }
    /**
     * creating getter methods to get the item
     * quantity and price of the product
     * @return
     */
    public String getItem(){
        return item;
    }
    public int getQuantity(){
        return quantity;
    }
    public double getPrice(){
        return price;
    }
    public String printItem(){
        return this.getItem() + " " + this.getQuantity() + " " + "GHC " + this.getPrice() + " ";
    }
}
	
